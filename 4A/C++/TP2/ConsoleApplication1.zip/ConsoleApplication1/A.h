#pragma once
#include "B.h"
class A {
private:
	double x;
	double y;
public:
	A(); // Constructeur par d�faut
	A(const A &a); // Constructeur par recopie
	A(const A &&a); // Constructeur par mouvement
	~A();
	A& operator=(const A &a); // Op�rateur d'affectation
	A& operator=(const A &&a); // Op�rateur de d�placement

	A(const B &b);
	A& A::operator=(const B &b);

};