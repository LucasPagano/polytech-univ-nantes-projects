#include "Point.h"
#include <iostream>

Point::Point() : x(0), y(0), z(0) {
	label = _strdup("");
}

Point::Point(double x, double y, double z, const char *label) {
	this->x = x;
	this->y = y;
	this->z = z;
	this->label = _strdup(label);
}

Point::Point(const Point &p) {
	this->x = p.x;
	this->y = p.y;
	this->z = p.z;
	this->label = _strdup(p.label);
}

Point::~Point() {
	free(this->label);
}

