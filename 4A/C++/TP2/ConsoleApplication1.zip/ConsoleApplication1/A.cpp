#include "A.h"
#include <iostream>


A::A(){
	std::cout << "Constructeur par defaut" << std::endl;
}

A::A(const A &a) {
	std::cout << "Constructeur par recopie" << std::endl;
}

A::A(const A &&a) {
	std::cout << "Constructeur par mouvement" << std::endl;

}

A::A(const B &b) {
	std::cout << "Recopie d'un objet B " << std::endl;
}


A::~A() {
	std::cout << "Destructeur" << std::endl;
}

A& A::operator=(const A &a) {
	std::cout << "Operateur d'affectation" << std::endl;
	return *this;
}

A& A::operator=(const A &&a) {
	std::cout << "Operateur de deplacement" << std::endl;
	return *this;
}

A& A::operator=(const B &b) {
	std::cout << "Operateur de deplacement avec un B" << std::endl;
	return *this;
}