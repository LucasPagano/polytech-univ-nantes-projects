#include "B.h"
#include <iostream>


B::B() {
	std::cout << "Constructeur par defaut" << std::endl;
}

B::B(const B &b) {
	std::cout << "Constructeur par recopie" << std::endl;
}

B::B(const B &&b) {
	std::cout << "Constructeur par mouvement" << std::endl;

}

B::~B() {
	std::cout << "Destructeur" << std::endl;
}

B& B::operator=(const B &b) {
	std::cout << "Operateur d'affectation" << std::endl;
	return *this;
}

B& B::operator=(const B &&b) {
	std::cout << "Operateur de d�placement" << std::endl;
	return *this;
}