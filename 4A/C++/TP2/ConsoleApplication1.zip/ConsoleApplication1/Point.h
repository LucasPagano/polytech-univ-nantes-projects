#pragma once
class Point {
private:
	double x;
	double y;
	double z;
	char *label;
public:
	Point();
	Point(double x, double y, double z, const char *label);
	Point(const Point&);
	~Point();
};