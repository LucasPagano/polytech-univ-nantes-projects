#pragma once
class Chaine {
private:
	char *string;
	unsigned int size;
public:
	Chaine();
	Chaine(char *string);
	Chaine(const Chaine &ch);
	~Chaine();

	unsigned int getSize();
	const char* getString();
	void addString(const char *str);
	void replaceString(const char *str);
};