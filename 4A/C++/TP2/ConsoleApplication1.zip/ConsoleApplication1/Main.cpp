#include "Chaine.h"
#include "A.h"
#include "B.h"
#include "Point.h"
#include <iostream>

using namespace std;

Point CreerPoint(double x, double y, double z, const char *label) {
	Point p(x, y, z, label);

	return (p);
}

Point CreerPoint(Point p) {
	Point p1(p);

	return (p1);
}



int main() {

	//Chaine chaine1("test1");
	//cout << chaine1.getString() << endl;
	//chaine1.addString("test2");

/*	A t;
	A z(t);
	A v = A();
	A y = t;
	z = t;

	A t;
	B u;
	A a(u);
	t = u;
	*/

	Point p1;
	Point p2(1.2, 0.0, 0.0, 0.3, "p2");
	Point p3 = Point(2, 3, 1.2, "p3");

	p1 = CreerPoint


	return 0;
}