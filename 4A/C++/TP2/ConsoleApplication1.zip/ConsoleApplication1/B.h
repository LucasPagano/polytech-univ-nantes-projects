#pragma once
class B {
private:
	double x;
	double y;
public:
	B(); // Constructeur pBr d�fBut
	B(const B&); // Constructeur par recopie
	B(const B&&); // Constructeur pBr mouvement
	~B();
	B& operator=(const B&); // Op�rBteur d'Bffectation
	B& operator=(const B&&); // Op�rBteur de d�placement
};