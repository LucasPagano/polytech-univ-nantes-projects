#include "Chaine.h"
#include <iostream>

Chaine::Chaine():size(0){
	string = _strdup("");
}

Chaine::Chaine(char *string) {
	this->string = _strdup(string);
	this->size = strlen(string);
}

Chaine::Chaine(const Chaine &ch) : size (ch.size) {
	string = _strdup(ch.string);

}


Chaine::~Chaine() {
	std::cout << "On detruit la chaine qui contenait le texte " << this->string << std::endl;
	free(string);
}

unsigned int Chaine::getSize() {
	return this->size;
}

const char* Chaine::getString() {
	return this->string;
}

void Chaine::addString(const char *stringAjout){
	this->size += strlen(stringAjout);
	string = (char *)realloc(string, size * sizeof(char));
	strcat(string, stringAjout);
}

void Chaine::replaceString(const char *stringReplace) {
	this->string = (char *)stringReplace;
	this->size = strlen(stringReplace);
}
