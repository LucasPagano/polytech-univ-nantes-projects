int main()
{
	Chaine c1;
	Chaine c2("Chaine 2");

	c1.AddString("Chaine");
	printf("c1=\"%s\"\nc2=\"%s\"\n\n",c1.GetString(),c2.GetString());
	/*
	Renvoi sur le terminal :
	c1="Chaine"
	c2="Chaine 2"
	*/

	Chaine c3(c1);
	c1.AddString(" 1");
	c2.ReplaceString("Nouvelle chaine");
	printf("c1=\"%s\"\nc2=\"%s\"\nc3=\"%s\"\n\n",c1.GetString(),c2.GetString(),c3.GetString());
	/*
	Renvoi sur le terminal :
	c1="Chaine 1"
	c2="Nouvelle chaine"
	c3="Chaine"
	*/

	return 0;
}
