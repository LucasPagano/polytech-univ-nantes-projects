int main()
{
	Chaine c1("Chaine 2");

	c1.AddString("Chaine");
	printf("c1=\"%s\"\n",c1.GetString());

	return 0;
}
