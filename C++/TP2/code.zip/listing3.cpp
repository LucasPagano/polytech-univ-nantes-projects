A t;
B u;
A a(u);
t=u;
