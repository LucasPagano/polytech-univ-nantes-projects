Point CreerPoint(double x,double y,double z,const char *label)
{
	Point p(x,y,z,label);

	return(p);
}

Point CreerPoint(Point p)(*@\label{alg:tempobj:fn}@*)
{
	Point p1(p);

	return(p1);
}

int main()
{
	Point p1;
	Point p2(1.2,0,0.3,"p2");
	Point p3=Point(2,3.1,2,"p3");

	p1=CreerPoint(2.4,8,3.5,"p1'");
	p1=CreerPoint(p2);
}
