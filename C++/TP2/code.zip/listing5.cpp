Point p1,p2;
double dist;

dist=Point::DistanceEnclidienne(p1,p2);
cout << "La distance euclidienne entre les points p1 et p2 est " << dist << endl;
