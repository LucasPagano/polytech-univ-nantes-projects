A t;
A z(t);
A v=A();
A y=t;
z=t;
