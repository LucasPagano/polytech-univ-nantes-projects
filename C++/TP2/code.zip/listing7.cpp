Chaine c1("Ma cha�ne");
Chaine c2;

cout << "Valeur de c1 : " << c1 << endl;
cin >> c2;
cout << "Valeur de c2 : " << c2 << endl;
